function fibonacci()
{
    let a,n1=0,n2=1,n3,i,series = '';
  
    a = parseInt(prompt('Enter number ')); 
    series = series + n1 ;
    // document.getElementById('my_res').textContent=n1;   
    // document.getElementById('my_res').textContent=n2;   
    series = series+ ',' + n2 ;

 for(i=2;i<a;++i)
 {    
  n3=n1+n2;    
  series = series + ','+ n3 ;  

  n1=n2;    
  n2=n3;    
 }  
document.getElementById('my_res').textContent = series;
}
